import { chromium } from 'playwright';

const browser = await chromium.launch({
  executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome',
  args: ['--no-sandbox'],
});

// Desktop context
const page = await (await browser.newContext({ viewport: { width: 1280, height: 800 } })).newPage();
const email = `tour_${Date.now()}@example.com`;

await page.goto('http://localhost:3100/');
await page.screenshot({ path: 'scratch/shots/01_landing.png' });

await page.fill('textarea', "I'm thinking about buying a house and don't know if I can afford it");
await page.click('button:has-text("Continue")');
await page.fill('input[type=email]', email);
await page.click('button:has-text("Continue")');
await page.waitForURL(/\/app\/ask\//);
await page.waitForTimeout(500);
await page.screenshot({ path: 'scratch/shots/02_chat.png' });

// Add some My Stuff so Tools has real numbers
await page.goto('http://localhost:3100/app/my-stuff/cash_banking');
await page.click('button:has-text("Connect it")');
await page.waitForURL(/connected=1/);
await page.goto('http://localhost:3100/app/my-stuff/credit_debt');
await page.click('button:has-text("Connect it")');
await page.waitForURL(/connected=1/);
await page.goto('http://localhost:3100/app/my-stuff');
await page.screenshot({ path: 'scratch/shots/03_my_stuff.png' });

await page.goto('http://localhost:3100/app/tools/home_affordability');
await page.waitForTimeout(300);
await page.screenshot({ path: 'scratch/shots/04_tools.png' });

await page.goto('http://localhost:3100/app/school');
await page.screenshot({ path: 'scratch/shots/05_school.png' });

await page.goto('http://localhost:3100/app/school/leverage');
await page.screenshot({ path: 'scratch/shots/06_leverage.png' });

await page.goto('http://localhost:3100/app/resources');
await page.screenshot({ path: 'scratch/shots/07_resources.png' });

// Mobile view
const mobile = await (await browser.newContext({ viewport: { width: 390, height: 844 } })).newPage();
await mobile.context().addCookies(await page.context().cookies());
await mobile.goto('http://localhost:3100/app');
await mobile.waitForTimeout(300);
await mobile.screenshot({ path: 'scratch/shots/08_mobile.png' });

console.log('done');
await browser.close();
